# Topic Password

## Installation

Copy the extension to phpBB/ext/mykeehu/topas

Go to "ACP" > "Customise" > "Extensions" and enable the "Topic Password" extension.

## License

[GPLv2](license.txt)
